# Janitri Login Automation

This project automates the login page of the Janitri Dashboard using Java, Selenium, and TestNG with the Page Object Model (POM) design.

## Tech Stack:
- Java
- Selenium WebDriver
- Maven
- TestNG

## Structure
- `base`: Contains BaseTest.java
- `pages`: Contains LoginPage.java
- `tests`: Contains LoginPageTests.java
- `testng.xml`: TestNG configuration file

## Run Tests
```bash
mvn test
```

## Notes
- Download and place Selenium JARs inside `libs/` folder.