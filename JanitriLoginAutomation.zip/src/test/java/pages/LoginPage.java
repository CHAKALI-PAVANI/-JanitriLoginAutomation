package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
    private WebDriver driver;

    private By userIdInput = By.id("email");
    private By passwordInput = By.id("password");
    private By loginButton = By.tagName("button");
    private By eyeIcon = By.cssSelector("svg");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public WebElement getUserIdInput() {
        return driver.findElement(userIdInput);
    }

    public WebElement getPasswordInput() {
        return driver.findElement(passwordInput);
    }

    public WebElement getLoginButton() {
        return driver.findElement(loginButton);
    }

    public WebElement getEyeIcon() {
        return driver.findElement(eyeIcon);
    }

    public boolean isLoginButtonEnabled() {
        return getLoginButton().isEnabled();
    }

    public void enterCredentials(String username, String password) {
        getUserIdInput().sendKeys(username);
        getPasswordInput().sendKeys(password);
    }

    public void clickLogin() {
        getLoginButton().click();
    }
}