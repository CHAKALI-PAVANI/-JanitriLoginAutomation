package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;

public class LoginPageTests extends BaseTest {

    @Test
    public void testLoginButtonDisabledWhenFieldsAreEmpty() {
        LoginPage loginPage = new LoginPage(driver);
        Assert.assertFalse(loginPage.isLoginButtonEnabled());
    }

    @Test
    public void testPasswordMaskedButton() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.getPasswordInput().sendKeys("password");
        String inputType = loginPage.getPasswordInput().getAttribute("type");
        Assert.assertEquals(inputType, "password");
    }

    @Test
    public void testInvalidLoginShowsErrorMessage() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterCredentials("wronguser", "wrongpass");
        loginPage.clickLogin();
        // This can be improved once specific error locators are known
    }
}